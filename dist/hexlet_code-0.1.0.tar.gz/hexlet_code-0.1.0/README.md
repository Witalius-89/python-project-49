### Hexlet tests and linter status:
[![Actions Status](https://github.com/Witalius-89/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Witalius-89/python-project-49/actions)(https://asciinema.org/a/FA8TYAF4QzAxoJEBEWEGaH5dI)(https://asciinema.org/a/b6lyfzTx7p1XmnzKSFpPGZ633)
